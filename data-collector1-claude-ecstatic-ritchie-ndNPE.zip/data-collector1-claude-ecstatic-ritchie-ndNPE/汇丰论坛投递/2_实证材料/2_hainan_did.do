*==============================================================================*
*  辅助实证：海南自由贸易港政策对生鲜跨境电商进口的影响（改进版 DID）
*------------------------------------------------------------------------------*
*  相对原稿的改进：
*   (1) 样本由 5 城30obs 扩展到 12 个沿海可比城市 × 10 年 = 120 obs
*   (2) 显式加入 covid 控制 + 区域时间趋势，缓解"政策与疫情同年(2020)"的混淆
*   (3) 补全事件研究多期前置项、规范的置换式安慰剂、PSM-DID、剔除样本检验
*  数据：data/hainan_panel.csv （当前为【模拟/占位】数据，投递前替换为真实数据）
*  环境：Stata 17.0+
*==============================================================================*

clear all
set more off
version 17

cap ssc install reghdfe
cap ssc install ftools
cap ssc install coefplot
cap ssc install estout
cap ssc install psmatch2
cap ssc install winsor2

* cd "/your/path/汇丰论坛投递/2_实证材料"
import delimited "data/hainan_panel.csv", clear encoding("utf-8")
encode city, gen(id)
xtset id year

label var did       "海南自贸港政策(treat×post)"
label var ln_import "生鲜进口额(对数)"
label var covid     "新冠疫情年(2020-2022)"

global X "ln_gdp ln_pop internet logistics_inv"

*==============================================================================*
* 1. 基准 DID（逐步加入控制变量 / 固定效应 / 疫情控制）
*==============================================================================*
eststo clear
eststo h1: reghdfe ln_import did, absorb(id year) vce(cluster id)
eststo h2: reghdfe ln_import did $X, absorb(id year) vce(cluster id)
* 关键改进：加入 covid 控制项，剥离疫情共同冲击
eststo h3: reghdfe ln_import did $X covid, absorb(id) vce(cluster id)
* 年份FE已吸收全样本共同年份冲击(含全国性疫情)，更稳健
eststo h4: reghdfe ln_import did $X, absorb(id year) vce(cluster id)

esttab h1 h2 h3 h4 using "output/h_tab1_baseline.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) keep(did $X covid) ///
    mtitles("(1)" "(2)" "(3)控疫情" "(4)双向FE") ///
    title("海南自贸港政策对生鲜进口的影响：基准回归") ///
    addnotes("括号内为城市层面聚类稳健标准误")

* 经济意义（对数因变量）：百分比效应 = exp(b)-1
qui reghdfe ln_import did $X, absorb(id year) vce(cluster id)
di "政策的百分比效应 ≈ " (exp(_b[did])-1)*100 " %"

*==============================================================================*
* 2. 平行趋势 / 事件研究（多期前置项，2020 为冲击年）
*==============================================================================*
gen event = year - 2020
* 以 event=-1 (2019) 为基准期
forvalues k = 5(-1)2 { gen pre`k' = (event==-`k') & treat==1 }
forvalues k = 0/4     { gen post`k' = (event==`k') & treat==1 }

eststo hes: reghdfe ln_import pre5 pre4 pre3 pre2 ///
                    post0 post1 post2 post3 post4 $X, ///
                    absorb(id year) vce(cluster id)
coefplot hes, keep(pre5 pre4 pre3 pre2 post0 post1 post2 post3 post4) ///
    vertical yline(0, lp(dash)) ///
    ciopts(recast(rcap)) ///
    coeflabels(pre5="-5" pre4="-4" pre3="-3" pre2="-2" ///
               post0="0" post1="+1" post2="+2" post3="+3" post4="+4") ///
    title("海南自贸港：平行趋势与动态效应") ///
    note("基准期 -1(2019)；处置前系数应不显著")
graph export "output/h_fig_parallel.png", replace width(1600)

*==============================================================================*
* 3. 稳健性检验
*==============================================================================*
* 3.1 安慰剂：随机指定 2 个城市为"伪处置组"，重复 1000 次（12城选2，组合充分）
set seed 20260529
local reps 1000
matrix HB = J(`reps',1,.)
levelsof id, local(ids)
forvalues r = 1/`reps' {
    preserve
    gen double u = runiform() if year==2015
    bysort id: egen uu = max(u)
    egen rk = rank(uu) if year==2015
    bysort id: egen rkc = max(rk)
    gen byte ftreat = rkc <= 2          // 随机 2 城为伪处置
    gen byte fpost  = year >= 2020
    gen byte fdid   = ftreat*fpost
    qui reghdfe ln_import fdid $X, absorb(id year) vce(cluster id)
    matrix HB[`r',1] = _b[fdid]
    restore
}
svmat HB, names(hplacebo)
qui reghdfe ln_import did $X, absorb(id year) vce(cluster id)
local rb = _b[did]
kdensity hplacebo1, normal xline(`rb', lc(red)) ///
    title("海南自贸港 安慰剂检验") note("红线为真实系数")
graph export "output/h_fig_placebo.png", replace width(1600)
gen byte hext = abs(hplacebo1) >= abs(`rb')
qui sum hext
di "海南安慰剂经验 p 值 = " r(mean)

* 3.2 剔除特定对照（珠海作为老牌特区，结构特殊）
eststo h_drop: reghdfe ln_import did $X if city!="Zhuhai", ///
    absorb(id year) vce(cluster id)

* 3.3 PSM-DID：处置前协变量匹配
preserve
keep if year <= 2019
collapse (mean) ln_gdp ln_pop internet logistics_inv treat, by(id)
psmatch2 treat ln_gdp ln_pop internet logistics_inv, logit n(2) common
keep id _weight
tempfile hw
save `hw'
restore
merge m:1 id using `hw', keep(match master) nogen
eststo h_psm: reghdfe ln_import did $X if _weight!=., ///
    absorb(id year) vce(cluster id)

* 3.4 替换被解释变量 / 反事实时间（伪政策年 2018）
gen post_fake = year >= 2018
gen did_fake  = treat*post_fake
eststo h_fake: reghdfe ln_import did_fake $X if year<=2019, ///
    absorb(id year) vce(cluster id)    // 伪政策年应不显著

esttab h_drop h_psm h_fake using "output/h_tab2_robust.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) keep(did did_fake) ///
    mtitles("剔除珠海" "PSM-DID" "伪政策年2018") ///
    title("海南自贸港：稳健性检验")

di as result "==== 辅助实证(海南自贸港 DID) 运行完成，结果见 output/ 目录 ===="
