*==============================================================================*
*  真实数据实证：自贸试验区(FTZ)对省级贸易的交错 DID + 双轮驱动协同
*  （与 real_ftz_did.py 等价的 Stata 实现，结果可相互验证）
*------------------------------------------------------------------------------*
*  数据：data/ftz_province_panel.csv
*    由 real_ftz_did.py 从公开免费数据(GitHub 中国省级面板 2000-2022)整理生成。
*    变量：prov year ln_trade ln_gdp sec ln_tech ln_popden ftz cbec did_syn
*           ftz_year cbec_year
*  环境：Stata 17.0+
*==============================================================================*
clear all
set more off
version 17
cap ssc install reghdfe
cap ssc install ftools
cap ssc install coefplot
cap ssc install estout
cap ssc install csdid
cap ssc install drdid

* cd "/your/path/汇丰论坛投递/2_实证材料"
import delimited "data/ftz_province_panel.csv", clear encoding("utf-8")
encode prov, gen(id)
xtset id year
label var ftz      "自贸试验区"
label var cbec     "跨境电商综试区"
label var did_syn  "双试点叠加(协同)"
label var ln_trade "进出口总额(对数)"
global X "ln_gdp sec ln_tech ln_popden"

*------------------------------------------------------------------------------*
* 1. 基准 DID：FTZ -> ln(trade)
*------------------------------------------------------------------------------*
eststo clear
eststo m1: reghdfe ln_trade ftz,        absorb(id year) vce(cluster id)
eststo m2: reghdfe ln_trade ftz $X,     absorb(id year) vce(cluster id)
* (3) 首选：加入省份特定线性趋势，吸收差异化预趋势
eststo m3: reghdfe ln_trade ftz $X,     absorb(id year i.id#c.year) vce(cluster id)
esttab m1 m2 m3 using "output/real_tab1_baseline.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) keep(ftz $X) ///
    mtitles("(1)双向FE" "(2)+控制" "(3)+省份趋势") ///
    title("表 自贸试验区对省级贸易的影响") ///
    addnotes("括号内为省份层面聚类稳健标准误；(3)为首选设定")
* 百分比效应
qui reghdfe ln_trade ftz $X, absorb(id year i.id#c.year) vce(cluster id)
di "FTZ 百分比效应 ≈ " (exp(_b[ftz])-1)*100 " %"

*------------------------------------------------------------------------------*
* 2. 双轮驱动协同：FTZ + CBEC + FTZ×CBEC
*------------------------------------------------------------------------------*
eststo syn: reghdfe ln_trade ftz cbec did_syn $X, ///
    absorb(id year i.id#c.year) vce(cluster id)
esttab syn using "output/real_tab2_synergy.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) keep(ftz cbec did_syn) ///
    title("表 双轮驱动协同效应(对应 H3)")
* H3：协同交互项 did_syn 显著为正 => 双试点叠加 1+1>2
test did_syn

*------------------------------------------------------------------------------*
* 3. 事件研究 / 平行趋势（相对 FTZ 设立年，基准 = -1）
*------------------------------------------------------------------------------*
gen rel = year - ftz_year if ftz_year > 0
* 端点归并
gen L4m = (rel<=-4) & ftz_year>0
gen L3  = (rel==-3) & ftz_year>0
gen L2  = (rel==-2) & ftz_year>0
gen F0  = (rel==0)  & ftz_year>0
gen F1  = (rel==1)  & ftz_year>0
gen F2  = (rel==2)  & ftz_year>0
gen F3p = (rel>=3)  & ftz_year>0
eststo es: reghdfe ln_trade L4m L3 L2 F0 F1 F2 F3p $X, ///
    absorb(id year i.id#c.year) vce(cluster id)
coefplot es, keep(L4m L3 L2 F0 F1 F2 F3p) vertical yline(0,lp(dash)) ///
    ciopts(recast(rcap)) ///
    coeflabels(L4m="-4" L3="-3" L2="-2" F0="0" F1="+1" F2="+2" F3p="+3+") ///
    title("事件研究：自贸区对省级贸易的动态效应") ///
    note("基准期 -1；省份线性趋势已控制；处置前系数应不显著")
graph export "output/real_event_study.png", replace width(1600)

*------------------------------------------------------------------------------*
* 4. 异质性稳健 DID（Callaway & Sant'Anna，应对交错处置 TWFE 负权重）
*------------------------------------------------------------------------------*
gen gvar = ftz_year
replace gvar = 0 if ftz_year==0          // never-treated 记为 0
cap csdid ln_trade $X, ivar(id) time(year) gvar(gvar) method(dripw) agg(simple)
cap estat event
cap csdid_plot
cap graph export "output/real_csdid.png", replace width(1600)

*------------------------------------------------------------------------------*
* 5. 安慰剂检验（随机化处置年份，1000 次）
*------------------------------------------------------------------------------*
set seed 20260529
qui reghdfe ln_trade ftz $X, absorb(id year i.id#c.year) vce(cluster id)
local realb = _b[ftz]
local reps 1000
matrix B = J(`reps',1,.)
levelsof id, local(ids)
forvalues r = 1/`reps' {
    preserve
    gen u = runiform() if year==2000
    bysort id: egen uu = max(u)
    * 70% 省份随机赋一个处置年, 30% 设为未处置
    gen fy = .
    foreach yy in 2013 2015 2017 2018 2019 2020 {
        replace fy = `yy' if uu>0 & mod(int(uu*100),6)==`=mod(`yy',6)'
    }
    replace fy = . if uu < 0.3
    gen byte fftz = (year>=fy) & fy!=.
    qui reghdfe ln_trade fftz $X, absorb(id year i.id#c.year) vce(cluster id)
    matrix B[`r',1] = _b[fftz]
    restore
}
svmat B, names(pb)
kdensity pb1, normal xline(`realb', lc(red)) ///
    title("安慰剂检验：随机化 FTZ 系数分布") note("红线为真实系数")
graph export "output/real_placebo.png", replace width(1600)
gen byte ext = abs(pb1) >= abs(`realb')
qui sum ext
di "安慰剂经验 p 值 = " r(mean)

*------------------------------------------------------------------------------*
* 6. 稳健性检验
*------------------------------------------------------------------------------*
eststo rb1: reghdfe ln_trade ftz $X if year<2020, absorb(id year i.id#c.year) vce(cluster id)
eststo rb2: reghdfe ln_trade ftz $X if !inlist(prov,"北京","上海","天津","重庆"), ///
    absorb(id year i.id#c.year) vce(cluster id)
eststo rb3: reghdfe ln_trade ftz $X if year>=2008, absorb(id year i.id#c.year) vce(cluster id)
esttab rb1 rb2 rb3 using "output/real_tab3_robust.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) keep(ftz) ///
    mtitles("剔除疫情年" "剔除直辖市" "仅2008-2022") ///
    title("表 稳健性检验")

di as result "==== 真实数据实证(FTZ DID + 协同) 运行完成，见 output/ ===="
