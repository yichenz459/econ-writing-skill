# -*- coding: utf-8 -*-
"""
====================================================================
 生鲜农产品跨境电商 · 双轮驱动协同效应实证 —— 数据集生成脚本
====================================================================

【重要声明 / DISCLAIMER】
本脚本生成的是【结构正确、清晰标注为"模拟/占位"的演示数据集】，
其唯一目的是让配套的 Stata .do 文件可以"开箱即跑"，验证代码逻辑、
图表与结果呈现是否正确。

数据本身由设定好的"数据生成过程(DGP)"人工合成，**不是真实统计数据**，
**不能用于论文正式结果**。投递前必须用《数据说明与获取指南.docx》中
列出的真实数据源（中国海关统计年鉴、中国城市统计年鉴等）替换，
保持本脚本输出文件的【列名与结构完全一致】，Stata 代码即可直接复用。

生成两份数据集：
  1) synergy_panel  —— 主实证：跨境电商综试区 × 自贸试验区"双轮驱动"协同
  2) hainan_panel   —— 辅助实证：海南自贸港单一政策（改进版，含疫情控制变量）

运行：python3 make_data.py
输出：data/synergy_panel.csv / .xlsx ，data/hainan_panel.csv / .xlsx
"""

import numpy as np
import csv
import os

np.random.seed(20260529)  # 固定随机种子，保证可复现
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUT, exist_ok=True)

# ====================================================================
# 数据集 1：主实证 —— 双轮驱动协同（城市 × 年份 面板）
# ====================================================================
# 设计：
#   - treat_ftz  : 城市当年是否设有自贸试验区片区（交错处置 staggered）
#   - treat_cbec : 城市当年是否为跨境电商综合试验区（交错处置 staggered）
#   - did_syn = treat_ftz * treat_cbec : "双试点叠加"，识别协同(1+1>2)效应
#   - 被解释变量 ln_fresh_x : 生鲜农产品跨境电商出口额(对数)
#   - 真实 DGP 中植入: 单轮各自正效应 + 显著为正的协同交互项，
#     以便代码跑出"可解读"的结果（真实数据下方向需自行检验）。

# 80 个地级及以上城市（示例命名 city01..city80），分 6 大区域
N_CITY = 80
YEARS = list(range(2011, 2025))   # 2011-2024，14 年
regions = ["East", "South", "Central", "North", "Southwest", "Northwest"]

# 各城市基础属性（城市固定效应、区域、规模）
city_fe = np.random.normal(0, 0.6, N_CITY)
city_region = np.random.choice(range(6), N_CITY)
city_base_gdp = np.random.normal(8.0, 0.7, N_CITY)   # ln GDP 基线（亿元）

# 交错处置：随机给部分城市分配 自贸区/综试区 获批年份
# 自贸区批次年份池（贴近现实：2013/2015/2017/2018/2019/2020/2023）
ftz_start_pool = [2013, 2015, 2017, 2018, 2019, 2020, 2023, None, None, None]
cbec_start_pool = [2015, 2016, 2018, 2019, 2020, 2022, None, None]

ftz_start = {c: np.random.choice(ftz_start_pool) for c in range(N_CITY)}
cbec_start = {c: np.random.choice(cbec_start_pool) for c in range(N_CITY)}

rows = []
for c in range(N_CITY):
    # 城市随时间的趋势项与控制变量演化
    trend = np.random.normal(0.04, 0.01)
    for t in YEARS:
        tt = t - 2011
        # 控制变量
        ln_gdp = city_base_gdp[c] + trend * tt + np.random.normal(0, 0.05)
        ln_pop = np.random.normal(6.2, 0.5) + 0.005 * tt
        internet = min(0.95, 0.35 + 0.04 * tt + np.random.normal(0, 0.03))      # 互联网普及率
        logistics_inv = np.random.normal(0.10, 0.06)                            # 物流投资增速
        fdi = np.random.normal(3.0, 0.8)                                        # ln 实际利用外资
        wage = np.random.normal(10.8, 0.2) + 0.02 * tt                          # ln 平均工资

        # 处置状态
        f = 1 if (ftz_start[c] is not None and t >= ftz_start[c]) else 0
        e = 1 if (cbec_start[c] is not None and t >= cbec_start[c]) else 0
        did_syn = f * e

        # 疫情冲击（2020-2022，对跨境贸易普遍冲击，作为共同年份效应一部分）
        covid = 1 if t in (2020, 2021, 2022) else 0

        # ---- 真实数据生成过程（DGP）----
        beta_ftz = 0.18      # 自贸区单轮效应
        beta_cbec = 0.22     # 综试区单轮效应
        beta_syn = 0.25      # 协同交互效应（核心：显著为正 => 1+1>2）
        ln_fresh_x = (
            3.0
            + city_fe[c]
            + 0.10 * tt                       # 共同时间趋势
            + 0.45 * ln_gdp
            + 0.20 * internet
            + 0.30 * logistics_inv
            + 0.05 * fdi
            + beta_ftz * f
            + beta_cbec * e
            + beta_syn * did_syn              # ← 协同效应
            - 0.15 * covid                    # 疫情负向共同冲击
            + np.random.normal(0, 0.20)       # 随机扰动
        )

        rows.append([
            f"city{c+1:02d}", regions[city_region[c]], t, f, e, did_syn,
            round(ln_fresh_x, 4), round(ln_gdp, 4), round(ln_pop, 4),
            round(internet, 4), round(logistics_inv, 4), round(fdi, 4), round(wage, 4),
            covid,
            ftz_start[c] if ftz_start[c] else "",
            cbec_start[c] if cbec_start[c] else "",
        ])

syn_header = ["city", "region", "year", "treat_ftz", "treat_cbec", "did_syn",
              "ln_fresh_x", "ln_gdp", "ln_pop", "internet", "logistics_inv",
              "fdi", "wage", "covid", "ftz_start_year", "cbec_start_year"]

# ====================================================================
# 数据集 2：辅助实证 —— 海南自贸港（沿海可比城市，2015-2024，含疫情控制）
# ====================================================================
# 改进点（相对原稿）：
#   - 样本扩展到 12 个沿海开放城市 × 10 年 = 120 obs（原稿仅 5 城 30 obs）
#   - 政策冲击年 2020；加入 covid 控制变量与 region×year 思路
#   - 处置组：海口、三亚；对照组：10 个其他沿海港口城市
hainan_cities = [
    ("Haikou", 1), ("Sanya", 1),                       # 处置组 treat=1
    ("Zhuhai", 0), ("Zhanjiang", 0), ("Beihai", 0),
    ("Xiamen", 0), ("Quanzhou", 0), ("Ningbo", 0),
    ("Qingdao", 0), ("Dalian", 0), ("Yantai", 0), ("Fangchenggang", 0),
]
HYEARS = list(range(2015, 2025))   # 2015-2024
hrows = []
for name, treat in hainan_cities:
    base = np.random.normal(24.0, 0.8)
    g = np.random.normal(0.03, 0.01)
    for t in HYEARS:
        tt = t - 2015
        post = 1 if t >= 2020 else 0
        did = treat * post
        covid = 1 if t in (2020, 2021, 2022) else 0
        ln_gdp = np.random.normal(8.2, 0.4) + 0.03 * tt
        ln_pop = np.random.normal(6.0, 0.4)
        internet = min(0.95, 0.45 + 0.04 * tt + np.random.normal(0, 0.02))
        logistics_inv = np.random.normal(0.12, 0.07)
        # DGP：海南自贸港政策正效应约 0.9（对数），叠加疫情负向共同冲击
        ln_import = (
            base + g * tt
            + 0.30 * ln_gdp + 0.15 * internet + 0.40 * logistics_inv
            + 0.90 * did
            - 0.20 * covid
            + np.random.normal(0, 0.15)
        )
        hrows.append([
            name, t, treat, post, did, round(ln_import, 4),
            round(ln_gdp, 4), round(ln_pop, 4), round(internet, 4),
            round(logistics_inv, 4), covid,
        ])

hainan_header = ["city", "year", "treat", "post", "did", "ln_import",
                 "ln_gdp", "ln_pop", "internet", "logistics_inv", "covid"]


# ---------------- 写出 CSV + XLSX ----------------
def write_csv(path, header, data):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(data)


def write_xlsx(path, header, data):
    try:
        from openpyxl import Workbook
    except ImportError:
        print("  (openpyxl 未安装，跳过 xlsx)")
        return
    wb = Workbook()
    ws = wb.active
    ws.append(header)
    for r in data:
        ws.append(list(r))
    wb.save(path)


write_csv(os.path.join(OUT, "synergy_panel.csv"), syn_header, rows)
write_xlsx(os.path.join(OUT, "synergy_panel.xlsx"), syn_header, rows)
write_csv(os.path.join(OUT, "hainan_panel.csv"), hainan_header, hrows)
write_xlsx(os.path.join(OUT, "hainan_panel.xlsx"), hainan_header, hrows)

print("已生成（模拟/占位数据，请用真实数据替换后再投递）：")
print(f"  synergy_panel : {len(rows)} obs, {N_CITY} cities x {len(YEARS)} years")
print(f"  hainan_panel  : {len(hrows)} obs, {len(hainan_cities)} cities x {len(HYEARS)} years")
print(f"  输出目录: {OUT}")
