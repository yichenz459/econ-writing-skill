*==============================================================================*
*  主实证：跨境电商综试区 × 自贸试验区 "双轮驱动" 协同效应 (DID)
*  对应论文假设 H3：双试点叠加对生鲜农产品跨境电商出口的促进作用
*               大于单一政策效应之和（1+1>2）
*------------------------------------------------------------------------------*
*  数据：data/synergy_panel.csv （当前为【模拟/占位】数据，投递前替换为真实数据）
*  说明：列名/结构须与 synergy_panel 保持一致；真实数据来源见《数据说明与获取指南》
*  环境：Stata 17.0+
*==============================================================================*

clear all
set more off
version 17

* ---- 0. 安装依赖（首次运行）----
cap ssc install reghdfe
cap ssc install ftools
cap ssc install coefplot
cap ssc install estout       // esttab 输出三线表
cap ssc install psmatch2
cap ssc install csdid         // Callaway & Sant'Anna 异质性稳健 DID
cap ssc install drdid
cap ssc install winsor2

* ---- 1. 读入数据 ----
* 请把工作路径改为本文件所在目录的 data 子目录
* cd "/your/path/汇丰论坛投递/2_实证材料"
import delimited "data/synergy_panel.csv", clear encoding("utf-8")

encode city,   gen(id)
encode region, gen(reg)
xtset id year

* 核心解释变量
*  treat_ftz  : 自贸试验区(片区) 当年是否存在
*  treat_cbec : 跨境电商综试区 当年是否存在
*  did_syn    : treat_ftz * treat_cbec  —— 双试点叠加(协同项)
gen byte double_pilot = did_syn          // 同义，便于事件研究

label var treat_ftz  "自贸试验区"
label var treat_cbec "跨境电商综试区"
label var did_syn    "双试点叠加(协同)"
label var ln_fresh_x "生鲜跨境电商出口额(对数)"

* 控制变量缩尾，降低极端值影响
winsor2 ln_fresh_x ln_gdp ln_pop internet logistics_inv fdi wage, ///
        cuts(1 99) replace

global X "ln_gdp ln_pop internet logistics_inv fdi wage"

*==============================================================================*
* 2. 描述性统计
*==============================================================================*
estpost summarize ln_fresh_x treat_ftz treat_cbec did_syn $X
esttab using "output/tab1_summary.rtf", replace ///
    cells("mean(fmt(3)) sd(fmt(3)) min(fmt(3)) max(fmt(3)) count(fmt(0))") ///
    title("表1 描述性统计") nonumber

*==============================================================================*
* 3. 基准回归：单轮效应 + 协同交互项
*    ln_fresh_x = α + β1·FTZ + β2·CBEC + β3·(FTZ×CBEC) + γ'X + μ_i + λ_t + ε
*    β3 即"双轮驱动"协同效应，预期 β3 > 0 且显著
*==============================================================================*
eststo clear

* (1) 仅交互项，城市+年份FE
eststo m1: reghdfe ln_fresh_x did_syn, absorb(id year) vce(cluster id)

* (2) 拆分单轮 + 协同，城市+年份FE
eststo m2: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn, ///
                   absorb(id year) vce(cluster id)

* (3) 加控制变量
eststo m3: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X, ///
                   absorb(id year) vce(cluster id)

* (4) 加省份(区域)×年份 联合固定效应，吸收区域层面共同冲击(含疫情区域异质性)
eststo m4: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X, ///
                   absorb(id year reg#year) vce(cluster id)

esttab m1 m2 m3 m4 using "output/tab2_baseline.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) ///
    keep(treat_ftz treat_cbec did_syn $X) ///
    mtitles("(1)" "(2)" "(3)" "(4)") ///
    title("表2 双轮驱动协同效应基准回归") ///
    addnotes("城市与年份固定效应已控制；括号内为城市层面聚类稳健标准误")

* 协同检验：H3 要求 β3>0（叠加效应大于两单轮之和的"超额"部分即 β3）
lincom did_syn          // 协同净效应
test treat_ftz + treat_cbec + did_syn = treat_ftz + treat_cbec   // 等价于 did_syn=0

*==============================================================================*
* 4. 平行趋势 / 事件研究（围绕城市"成为双试点"的相对年份）
*==============================================================================*
* 构造相对事件时间：以城市首次同时拥有两类试点的年份为 0 期
bysort id (year): egen byte ever_dp = max(did_syn)
gen evyr = .
bysort id (year): replace evyr = year if did_syn==1 & did_syn[_n-1]==0
bysort id (evyr): egen first_dp_year = min(evyr)
gen rel = year - first_dp_year
* 以 rel = -1 为基准期，生成前后虚拟变量（窗口 -4 .. +4）
forvalues k = 4(-1)2 {
    gen lead`k' = (rel == -`k') & ever_dp==1
}
gen lead1 = (rel == -1) & ever_dp==1      // 基准期(略去)
forvalues k = 0/4 {
    gen lag`k' = (rel == `k') & ever_dp==1
}
* rel<=-5 与 rel>=5 归入端点
gen lead_far = (rel <= -5) & ever_dp==1
gen lag_far  = (rel >= 5)  & ever_dp==1

eststo es: reghdfe ln_fresh_x lead_far lead4 lead3 lead2 ///
                   lag0 lag1 lag2 lag3 lag4 lag_far $X, ///
                   absorb(id year) vce(cluster id)

coefplot es, keep(lead4 lead3 lead2 lag0 lag1 lag2 lag3 lag4) ///
    vertical yline(0, lp(dash)) xline(3.5, lp(dash)) ///
    ciopts(recast(rcap)) ///
    coeflabels(lead4="-4" lead3="-3" lead2="-2" ///
               lag0="0" lag1="+1" lag2="+2" lag3="+3" lag4="+4") ///
    title("平行趋势与动态效应检验") ///
    note("基准期为 -1；处置前系数应不显著异于 0")
graph export "output/fig_parallel_trend.png", replace width(1600)

*==============================================================================*
* 5. 稳健性检验
*==============================================================================*

* 5.1 安慰剂检验：随机置换"双试点"城市身份，重复 1000 次（多城市，组合充分）
*     收集随机交互项系数分布，看真实系数是否为离群值
cap program drop placebo
program define placebo, rclass
    preserve
    bysort id: gen byte first_obs = (_n==1)
    * 随机重排 ever_dp 的城市标签
    gen double u = runiform() if first_obs
    bysort id: egen double uu = max(u)
    egen rank = rank(uu) if first_obs
    * 用真实双试点城市数量做随机抽取
    qui sum ever_dp if first_obs
    local nt = r(sum)
    gsort -uu
    gen byte fake_ever = 0
    * 这里用相对年份近似构造随机 did
    qui reghdfe ln_fresh_x did_syn, absorb(id year) vce(cluster id)
    restore
end
* 简化稳健的置换：直接打乱处置年份后重估交互项
set seed 12345
local reps 1000
matrix B = J(`reps',1,.)
forvalues r = 1/`reps' {
    preserve
    bysort id (year): gen rnd = runiform() if _n==1
    bysort id: egen rndc = max(rnd)
    * 随机生成两类试点起始年（在样本年份内）
    gen f_start = floor(2011 + 14*runiform()) if _n==1
    bysort id: egen fstart = max(f_start)
    gen e_start = floor(2011 + 14*runiform()) if _n==1
    bysort id: egen estart = max(e_start)
    gen byte pf = year >= fstart
    gen byte pe = year >= estart
    gen byte pdid = pf*pe
    qui reghdfe ln_fresh_x pf pe pdid $X, absorb(id year) vce(cluster id)
    matrix B[`r',1] = _b[pdid]
    restore
}
svmat B, names(placebo_b)
* 真实协同系数
qui reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X, absorb(id year) vce(cluster id)
local realb = _b[did_syn]
kdensity placebo_b1, normal xline(`realb', lc(red)) ///
    title("安慰剂检验：随机化协同系数分布") ///
    note("红线为真实估计系数")
graph export "output/fig_placebo.png", replace width(1600)
* 经验 p 值
gen byte extreme = abs(placebo_b1) >= abs(`realb')
qui sum extreme
di "安慰剂经验 p 值 = " r(mean)

* 5.2 PSM-DID：按处置前协变量将双试点城市与对照城市匹配，再做 DID
preserve
keep if year <= 2017      // 以处置前期均值匹配（按需调整）
collapse (mean) ln_gdp ln_pop internet logistics_inv fdi wage ever_dp, by(id)
psmatch2 ever_dp ln_gdp ln_pop internet logistics_inv fdi wage, ///
    logit n(1) common ate
keep id _weight
tempfile w
save `w'
restore
merge m:1 id using `w', keep(match master) nogen
eststo psm: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X ///
    if _weight!=. , absorb(id year) vce(cluster id)

* 5.3 异质性稳健 DID（Callaway & Sant'Anna）：以"成为双试点"为交错处置
*     gvar = 城市首次成为双试点的年份（never-treated 取 0）
gen gvar = first_dp_year
replace gvar = 0 if ever_dp==0 | first_dp_year==.
cap csdid ln_fresh_x $X, ivar(id) time(year) gvar(gvar) ///
    method(dripw) agg(simple)
cap estat event, window(-4 4)
cap csdid_plot, title("CSDID 动态效应")
cap graph export "output/fig_csdid.png", replace width(1600)

* 5.4 剔除直辖市/特大城市样本（以 city01 为例，按真实数据替换）
eststo drop_big: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X ///
    if city!="city01", absorb(id year) vce(cluster id)

* 5.5 排除疫情年份（2020-2022）以排除新冠共同冲击的干扰
eststo no_covid: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X ///
    if covid==0, absorb(id year) vce(cluster id)

* 5.6 替换聚类层级（省份/区域层面聚类）
eststo cl_reg: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn $X, ///
    absorb(id year) vce(cluster reg)

esttab psm drop_big no_covid cl_reg using "output/tab3_robust.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) ///
    keep(treat_ftz treat_cbec did_syn) ///
    mtitles("PSM-DID" "剔除特大城市" "排除疫情年" "区域聚类") ///
    title("表3 稳健性检验")

*==============================================================================*
* 6. 机制 / 异质性（可选，配合论文机制章节）
*==============================================================================*
* 物流投资的调节作用：协同项 × 物流投资
gen did_log = did_syn * logistics_inv
eststo mech: reghdfe ln_fresh_x treat_ftz treat_cbec did_syn did_log $X, ///
    absorb(id year) vce(cluster id)
esttab mech using "output/tab4_mechanism.rtf", replace ///
    b(3) se(3) star(* 0.1 ** 0.05 *** 0.01) ///
    keep(did_syn did_log) title("表4 机制检验：物流投资调节作用")

di as result "==== 主实证(双轮协同 DID) 运行完成，结果见 output/ 目录 ===="
