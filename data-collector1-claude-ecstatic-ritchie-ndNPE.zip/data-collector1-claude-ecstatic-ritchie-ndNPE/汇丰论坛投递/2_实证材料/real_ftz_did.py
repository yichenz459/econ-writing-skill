# -*- coding: utf-8 -*-
"""
================================================================================
 真实数据实证：自贸试验区(FTZ)设立对省级贸易开放的交错 DID（含双轮驱动协同）
================================================================================
数据来源（免费、可公开下载，无需付费）：
  GitHub: KarlHeinrich-jpg/China-Provincial-Panel-Dataset-on-Economic-
  Development-Energy-and-CO2-Emissions-2000-2022  —— data.xlsx
  31 省级行政区 2000-2022 年平衡面板（本文用到 30 省，原始数据缺西藏）。
  变量含：GDP、进出口总额、第二产业占比、技术市场成交额、人口密度、CO2 等。

处置变量（公开政策事实，可核验）：
  ftz   = 省级首个自贸试验区(片区)获批当年起 = 1（交错处置）
  cbec  = 省级首个跨境电商综合试验区获批当年起 = 1（城市→省份归并）
  did_syn = ftz × cbec  —— 双试点叠加(协同项，对应论文 H3)

被解释变量：ln(进出口总额)。
方法：TWFE-DID + 省份特定线性趋势(处理差异化预趋势) + 事件研究 + 置换安慰剂。
本脚本用 numpy 复现（无需 Stata），输出真实系数、结果 JSON 与事件研究图。
配套 real_ftz_did.do 给出等价 Stata 实现。
================================================================================
"""
import openpyxl, numpy as np, csv, os, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
# 优先使用随仓库提供的真实数据副本；缺失时回退到 /tmp 下载副本
SRC  = os.path.join(HERE, "data", "raw_province_panel_2000_2022.xlsx")
if not os.path.exists(SRC):
    SRC = "/tmp/prov/data.xlsx"
OUT  = os.path.join(HERE, "data")
FIG  = os.path.join(HERE, "output")
os.makedirs(OUT, exist_ok=True); os.makedirs(FIG, exist_ok=True)

FTZ_YEAR = {"上海":2013,"广东":2015,"天津":2015,"福建":2015,"辽宁":2017,"浙江":2017,
 "河南":2017,"湖北":2017,"重庆":2017,"四川":2017,"陕西":2017,"海南":2018,"山东":2019,
 "江苏":2019,"广西":2019,"河北":2019,"云南":2019,"黑龙江":2019,"北京":2020,"湖南":2020,
 "安徽":2020,"新疆":2023}
CBEC_YEAR = {"浙江":2015,"天津":2016,"上海":2016,"重庆":2016,"安徽":2016,"河南":2016,
 "广东":2016,"四川":2016,"辽宁":2016,"山东":2016,"江苏":2016,"北京":2018,"内蒙古":2018,
 "吉林":2018,"黑龙江":2018,"江西":2018,"湖北":2018,"湖南":2018,"广西":2018,"海南":2018,
 "贵州":2018,"云南":2018,"陕西":2018,"甘肃":2018,"福建":2018,"河北":2019,"山西":2019,
 "宁夏":2019,"青海":2020,"新疆":2020}

# ---------- 读入真实数据 ----------
wb = openpyxl.load_workbook(SRC, read_only=True); ws = wb["Sheet1"]; rec=[]
for r in ws.iter_rows(min_row=2, values_only=True):
    if r[1] is None: continue
    y=int(r[0]); p=r[1]; gdp=float(r[2]); tr=float(r[3]); sec=float(r[4])
    tech=float(r[5]); pdn=float(r[8])
    fy=FTZ_YEAR.get(p,9999); cy=CBEC_YEAR.get(p,9999)
    rec.append(dict(prov=p, year=y, ln_trade=np.log(tr), ln_gdp=np.log(gdp),
        sec=sec, ln_tech=np.log(tech+1), ln_popden=np.log(pdn),
        ftz=1 if fy<=y<=2022 else 0, cbec=1 if cy<=y<=2022 else 0,
        ftz_year=fy if fy<=2022 else 0, cbec_year=cy if cy<=2022 else 0))
for d in rec: d["did_syn"]=d["ftz"]*d["cbec"]
provs=sorted(set(d["prov"] for d in rec)); years=sorted(set(d["year"] for d in rec))
X0=["ln_gdp","sec","ln_tech","ln_popden"]

# ---------- 通用 TWFE 估计器（省份+年份FE，可选省份线性趋势，省份聚类）----------
def twfe(rec, y, treats, xv, prov_trend=False, cluster="prov"):
    us=sorted(set(d["prov"] for d in rec)); ts=sorted(set(d["year"] for d in rec))
    X=[]; Y=[]; cl=[]
    for d in rec:
        row=[1.0]+[d[t] for t in treats]+[d[v] for v in xv]
        row+=[1.0 if d["prov"]==u else 0 for u in us[1:]]
        row+=[1.0 if d["year"]==t else 0 for t in ts[1:]]
        if prov_trend:
            row+=[(d["year"]-2000) if d["prov"]==u else 0 for u in us]
        X.append(row); Y.append(d[y]); cl.append(d[cluster])
    X=np.array(X); Y=np.array(Y); XtXi=np.linalg.pinv(X.T@X); b=XtXi@X.T@Y; e=Y-X@b
    cls=sorted(set(cl)); M=np.zeros((X.shape[1],)*2)
    for c in cls:
        idx=[i for i,cc in enumerate(cl) if cc==c]; s=X[idx].T@e[idx]; M+=np.outer(s,s)
    G=len(cls); n,k=X.shape; cov=(G/(G-1))*((n-1)/(n-k))*XtXi@M@XtXi
    se=np.sqrt(np.diag(cov)); names=["const"]+treats+xv
    # R2
    r2=1-(e@e)/((Y-Y.mean())@(Y-Y.mean()))
    return {nm:(b[i],se[i],b[i]/se[i]) for i,nm in enumerate(names)}, n, G, r2

def stars(t):
    a=abs(t); return "***" if a>2.576 else "**" if a>1.96 else "*" if a>1.645 else ""

print(f"真实面板: {len(rec)} obs, {len(provs)} 省, {years[0]}-{years[-1]}")
treated=[p for p in provs if FTZ_YEAR.get(p,9999)<=2022]
print(f"FTZ处置省份({len(treated)})；未处置对照({len(provs)-len(treated)}): "
      f"{[p for p in provs if p not in treated]}")

R={}
# (1) 基准（无趋势）  (2) +控制  (3) +省份线性趋势(首选)
print("\n=== 表 基准 DID：FTZ → ln(进出口) ===")
res,n,G,r2=twfe(rec,"ln_trade",["ftz"],[]); b,se,t=res["ftz"]
print(f"(1) FTZ+双向FE            b={b:.3f} se={se:.3f} t={t:.2f}{stars(t)}  N={n}"); R["m1"]=(b,se,t,n,r2)
res,n,G,r2=twfe(rec,"ln_trade",["ftz"],X0); b,se,t=res["ftz"]
print(f"(2) +控制变量            b={b:.3f} se={se:.3f} t={t:.2f}{stars(t)}  %={(np.exp(b)-1)*100:.1f}%"); R["m2"]=(b,se,t,n,r2)
res,n,G,r2=twfe(rec,"ln_trade",["ftz"],X0,prov_trend=True); b,se,t=res["ftz"]
print(f"(3) +省份线性趋势(首选)   b={b:.3f} se={se:.3f} t={t:.2f}{stars(t)}  %={(np.exp(b)-1)*100:.1f}%"); R["m3"]=(b,se,t,n,r2)

print("\n=== 表 双轮驱动协同：FTZ + CBEC + FTZ×CBEC (+省份趋势) ===")
res,n,G,r2=twfe(rec,"ln_trade",["ftz","cbec","did_syn"],X0,prov_trend=True)
for v in ["ftz","cbec","did_syn"]:
    b,se,t=res[v]; print(f"  {v:8s} b={b:.3f} se={se:.3f} t={t:.2f}{stars(t)}")
    R["syn_"+v]=(b,se,t)

# ---------- 事件研究（含省份趋势）----------
ll=[("L4m","r<=-4"),("L3","r==-3"),("L2","r==-2"),
    ("F0","r==0"),("F1","r==1"),("F2","r==2"),("F3p","r>=3")]
for d in rec:
    rr=(d["year"]-d["ftz_year"]) if d["ftz_year"]>0 else -999
    for nm,c in ll: d[nm]=1.0 if (d["ftz_year"]>0 and eval(c,{},{"r":rr})) else 0.0
res,n,G,r2=twfe(rec,"ln_trade",[nm for nm,_ in ll],X0,prov_trend=True)
print("\n=== 事件研究(基准=-1, 含省份趋势) ===")
ev=[]
for nm,_ in ll:
    b,se,t=res[nm]; ev.append((nm,b,se,t)); print(f"  {nm:5s} b={b:+.3f} t={t:+.2f}{stars(t)}")
R["event"]=ev

# 画事件研究图
labels=["-4","-3","-2","-1","0","+1","+2","+3+"]
coefs=[ev[0][1],ev[1][1],ev[2][1],0.0,ev[3][1],ev[4][1],ev[5][1],ev[6][1]]
ses  =[ev[0][2],ev[1][2],ev[2][2],0.0,ev[3][2],ev[4][2],ev[5][2],ev[6][2]]
xs=range(len(labels))
plt.figure(figsize=(7,4))
plt.errorbar(xs,coefs,yerr=[1.96*s for s in ses],fmt='o-',capsize=3,color="#1F3764")
plt.axhline(0,ls="--",color="grey"); plt.axvline(3,ls="--",color="red",alpha=.5)
plt.xticks(list(xs),labels); plt.xlabel("Years relative to FTZ establishment")
plt.ylabel("Coefficient on ln(trade)")
plt.title("Event study: FTZ effect on provincial trade (with province trends)")
plt.tight_layout(); plt.savefig(os.path.join(FIG,"real_event_study.png"),dpi=150)
print("已保存事件研究图 output/real_event_study.png")

# ---------- 置换安慰剂(1000次) ----------
rng=np.random.default_rng(20260529)
real_b=R["m3"][0]; pool=[2013,2015,2017,2018,2019,2020]; pb=[]
for _ in range(1000):
    fake={p:(rng.choice(pool) if rng.random()<0.7 else 9999) for p in provs}
    for d in rec: d["fftz"]=1 if (fake[d["prov"]]<=d["year"] and fake[d["prov"]]<=2022) else 0
    try:
        r,_,_,_=twfe(rec,"ln_trade",["fftz"],X0,prov_trend=True); pb.append(r["fftz"][0])
    except Exception: pass
pb=np.array(pb); pval=float(np.mean(np.abs(pb)>=abs(real_b)))
print(f"\n=== 安慰剂(1000次, 含省份趋势): 真实={real_b:.3f} 均值={pb.mean():.3f} 经验p={pval:.4f} ===")
R["placebo_p"]=pval
plt.figure(figsize=(7,4)); plt.hist(pb,bins=40,color="#9DB4D4",edgecolor="white")
plt.axvline(real_b,color="red",lw=2,label=f"True={real_b:.3f}")
plt.xlabel("Placebo FTZ coefficient"); plt.ylabel("Frequency")
plt.title("Placebo test (1000 random treatment reassignments)"); plt.legend()
plt.tight_layout(); plt.savefig(os.path.join(FIG,"real_placebo.png"),dpi=150)

# ---------- 稳健性 ----------
print("\n=== 稳健性 ===")
sub=[d for d in rec if d["year"]<2020]
res,_,_,_=twfe(sub,"ln_trade",["ftz"],X0,prov_trend=True); b,se,t=res["ftz"]
print(f"  剔除疫情年(2020-22)   ftz b={b:.3f} t={t:.2f}{stars(t)}"); R["rb_nocovid"]=(b,se,t)
sub=[d for d in rec if d["prov"] not in ("北京","上海","天津","重庆")]
res,_,_,_=twfe(sub,"ln_trade",["ftz"],X0,prov_trend=True); b,se,t=res["ftz"]
print(f"  剔除四直辖市         ftz b={b:.3f} t={t:.2f}{stars(t)}"); R["rb_nomuni"]=(b,se,t)
sub=[d for d in rec if d["year"]>=2008]
res,_,_,_=twfe(sub,"ln_trade",["ftz"],X0,prov_trend=True); b,se,t=res["ftz"]
print(f"  仅2008-2022          ftz b={b:.3f} t={t:.2f}{stars(t)}"); R["rb_2008"]=(b,se,t)

# ---------- 保存分析数据集 + 结果 ----------
keys=["prov","year","ln_trade","ln_gdp","sec","ln_tech","ln_popden","ftz","cbec","did_syn","ftz_year","cbec_year"]
with open(os.path.join(OUT,"ftz_province_panel.csv"),"w",newline="",encoding="utf-8-sig") as f:
    w=csv.writer(f); w.writerow(keys)
    for d in rec: w.writerow([round(d[k],6) if isinstance(d[k],float) else d[k] for k in keys])
with open(os.path.join(OUT,"results_summary.json"),"w",encoding="utf-8") as f:
    json.dump({k:(list(v) if isinstance(v,(tuple,)) else
                  [list(x) for x in v] if k=="event" else v) for k,v in R.items()},
              f, ensure_ascii=False, indent=2)
print("\n已保存 data/ftz_province_panel.csv 与 data/results_summary.json")
