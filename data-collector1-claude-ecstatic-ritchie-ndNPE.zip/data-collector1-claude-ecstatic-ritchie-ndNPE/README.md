# data-collector1


> 数据采集与整理工作库 — 自动抓取数据、生成 CSV / Excel，供 Stata、QGIS 等分析工具直接使用

---

## 📁 目录结构

```
data-collector/
├── README.md
├── scrapers/
│   ├── web_scraper.py          # 通用网页数据抓取
│   ├── api_fetcher.py          # API 接口数据拉取
│   ├── pdf_extractor.py        # PDF 表格提取
│   └── excel_reader.py         # 读取/合并多个 Excel 文件
├── processors/
│   ├── clean.py                # 数据清洗（去重、填缺、格式统一）
│   ├── merge.py                # 多来源数据合并
│   ├── geocode.py              # 地址转坐标（供 QGIS 使用）
│   └── reshape.py              # 宽表/长表转换
├── exporters/
│   ├── to_csv.py               # 导出 CSV
│   ├── to_excel.py             # 导出格式化 Excel（含公式）
│   └── to_stata.py             # 导出 .dta（Stata 格式）
├── templates/
│   ├── data_template.xlsx      # 标准数据收集模板
│   └── report_template.xlsx    # 数据汇总报告模板
├── output/
│   ├── csv/                    # 输出的 CSV 文件
│   ├── excel/                  # 输出的 Excel 文件
│   └── stata/                  # 输出的 .dta 文件
├── notebooks/
│   └── exploration.ipynb       # 数据探索笔记本
├── requirements.txt
└── .gitignore
```

---

## 🚀 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

`requirements.txt` 内容：
```
pandas==2.0.3
openpyxl==3.1.2
requests==2.31.0
beautifulsoup4==4.12.2
selenium==4.15.0
pdfplumber==0.10.3
geopy==2.4.0
pyreadstat==1.2.4
lxml==4.9.3
```

---

## 📋 使用示例

### 1. 网页数据抓取 → CSV

```python
import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://example.com/data-table"
response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
soup = BeautifulSoup(response.text, "lxml")

table = soup.find("table")
df = pd.read_html(str(table))[0]

df.to_csv("output/csv/result.csv", index=False, encoding="utf-8-sig")
print(f"✅ 已保存 {len(df)} 行数据")
```

### 2. API 拉取数据 → Excel

```python
import requests
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

# 拉取数据
response = requests.get("https://api.example.com/data", params={"year": 2024})
data = response.json()["records"]
df = pd.DataFrame(data)

# 导出带格式的 Excel
with pd.ExcelWriter("output/excel/data.xlsx", engine="openpyxl") as writer:
    df.to_excel(writer, sheet_name="数据", index=False)
    ws = writer.sheets["数据"]
    # 表头加粗 + 蓝色背景
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", start_color="1F4E79")
```

### 3. PDF 表格提取 → CSV

```python
import pdfplumber
import pandas as pd

with pdfplumber.open("input/report.pdf") as pdf:
    all_tables = []
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            df = pd.DataFrame(table[1:], columns=table[0])
            all_tables.append(df)

result = pd.concat(all_tables, ignore_index=True)
result.to_csv("output/csv/pdf_extracted.csv", index=False, encoding="utf-8-sig")
```

### 4. 地址转坐标（供 QGIS 使用）

```python
from geopy.geocoders import Nominatim
import pandas as pd
import time

df = pd.read_csv("output/csv/data.csv")
geolocator = Nominatim(user_agent="my_project")

def geocode(address):
    try:
        loc = geolocator.geocode(address, timeout=10)
        time.sleep(1)  # 避免频率限制
        return (loc.latitude, loc.longitude) if loc else (None, None)
    except:
        return (None, None)

df[["lat", "lon"]] = df["address"].apply(geocode).apply(pd.Series)
df.to_csv("output/csv/geocoded.csv", index=False, encoding="utf-8-sig")
```

### 5. 导出 Stata 格式

```python
import pandas as pd
import pyreadstat

df = pd.read_csv("output/csv/result.csv")
pyreadstat.write_dta(df, "output/stata/result.dta")
```

---

## 📊 Excel 模板说明

`templates/data_template.xlsx` 包含以下 Sheet：

| Sheet 名 | 用途 |
|----------|------|
| `填报表` | 手动录入数据的标准格式 |
| `汇总` | 自动汇总公式（勿手动修改）|
| `说明` | 字段定义与填报说明 |

---

## 🔄 标准数据流程

```
数据来源（网页/API/PDF/Excel）
        ↓
   scrapers/ 抓取
        ↓
  processors/ 清洗合并
        ↓
  exporters/ 导出
        ↓
  CSV → Stata 分析
  CSV → QGIS 地图
  Excel → 报告生成
```

---

## .gitignore 建议

```
output/
notebooks/.ipynb_checkpoints/
*.dta
*.csv
input/
__pycache__/
.env
```

---

## 📌 说明

- 所有导出 CSV 使用 `utf-8-sig` 编码，确保 Excel 直接打开不乱码
- 地理编码脚本有速率限制，大批量地址建议使用付费 API（如高德、百度）
- `output/` 目录不纳入版本控制，仅保留脚本和模板
